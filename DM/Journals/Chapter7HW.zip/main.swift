func createMatrix(size: Int) -> [[Bool]] {
    precondition(size >= 2, "matrix must have size of atleast 2")
    var matrix = [[Bool]]()
    for i in 0 ..< size {
        matrix.append([])
        for _ in 0 ..< size {
            matrix[i].append(Bool.random())
        }
    }
    return matrix
}

func printMatrix(_ matrix: [[Bool]], colorIndex: Int = -1) {
    for (y, row) in matrix.enumerated() {
        if y == colorIndex{
            printRow(row, colorIndex: colorIndex)
        } else {
            printRow(row)
        }
    }
    
}

func printRow(_ row: [Bool], colorIndex: Int = -1) {
    print("\t", terminator: "") //tabs
    for (x, square) in row.enumerated() {
        var color = "\u{001B}[39m" //default color
        if x == colorIndex {
            color = "\u{001B}[31m" //red
        }
        if square == false {
            print(color, "\u{25A1}", "\u{001B}[39m", terminator: "") //empty square
        } else if square == true {
            print(color, "\u{25A0}", "\u{001B}[39m", terminator: "") //full square
        }
    }
    print("")
}

func main() {
    let matrixSize = 10
    print("\u{001B}[2J") //clears screen
    var matrix = createMatrix(size: matrixSize)
    printMatrix(matrix)
    print("\n ESC + enter to quit, enter to continue")
    while readLine() != Optional("\u{1B}") { //only escapes with "esc" key
        var refRow = [Bool]()
        for index in 0 ..< matrixSize {
            print("\u{001B}[2J") //clears screen
            
            if matrix[index][index] == true { //creates refrow
                refRow.append(false)
            } else {
                refRow.append(true)
            }
            
            printRow(refRow, colorIndex: index)
            printMatrix(matrix, colorIndex: index)
            print("\n ESC + enter to quit, enter to continue")
            if readLine() == Optional("\u{1B}") { break }
        }
        matrix.insert(refRow, at: 0)
        print("\u{001B}[2J") //clears screen
        printMatrix(matrix)
        if readLine() == Optional("\u{1B}") { break }
        matrix.removeLast()
        print("\u{001B}[2J") //clears screen
        printMatrix(matrix)
        if readLine() == Optional("\u{1B}") { break }
    }
}

main()
